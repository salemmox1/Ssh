#!/bin/bash

BASE_DIR=$1
CACHE_FILE="$BASE_DIR/core/qemu/current_task.json"
RUN_SCRIPT="$BASE_DIR/core/qemu/qemu_run.sh"
VM_NAME="vortax_vm"

# المسارات الأساسية
MNT_PATH="/mnt"
TEMP_PATH="/mnt/tmp_unpack"
DISK_PATH="$MNT_PATH/main_disk.qcow2"
ISO_PATH="$BASE_DIR/boot_disk.iso"
FILE_PATH="$TEMP_PATH/source_file"
VIRTIO_ISO="/mnt/virtio-win.iso"

if [ ! -f "$CACHE_FILE" ]; then exit 1; fi

# جلب البيانات من الكاش (الافتراضي BIOS)
SRC=$(python3 -c "import json; print(json.load(open('$CACHE_FILE'))['url'])")
CAT=$(python3 -c "import json; print(json.load(open('$CACHE_FILE'))['category'])")
SIZE=$(python3 -c "import json; print(json.load(open('$CACHE_FILE'))['disk_size'])")
VCPUS="2"
RAM="4"

# 1. تنظيف البيئة وقتل أي محاكي يعمل
pkill -f qemu-system
screen -S $VM_NAME -X quit 2>/dev/null
sudo rm -rf "$TEMP_PATH"
sudo rm -f "$DISK_PATH"
sudo rm -f "$ISO_PATH"
sudo mkdir -p "$TEMP_PATH"

# 2. تحميل النظام (Smart Download)
echo "Downloading System Files..."
if [[ "$SRC" == *"archive.org/download/"* ]]; then
    ITEM=$(basename "$(dirname "$SRC")")
    FILE=$(basename "$SRC")
    ia download "$ITEM" "$FILE" --dest "$TEMP_PATH"
    mv "$TEMP_PATH/$FILE" "$FILE_PATH"
else
    sudo wget -q --user-agent="Mozilla/5.0" -O "$FILE_PATH" "$SRC"
fi

# 3. معالجة الملفات (ISO أو قرص جاهز)
EXT=$(file -b --mime-type "$FILE_PATH")

if [[ "$CAT" == "self_install" ]]; then
    sudo mv "$FILE_PATH" "$ISO_PATH"
    sudo qemu-img create -f qcow2 "$DISK_PATH" "${SIZE}G"
    BOOT_OPTS="-boot d -cdrom $ISO_PATH"
else
    if [[ "$EXT" == *"zip"* || "$EXT" == *"7z"* || "$EXT" == *"x-7z-compressed"* ]]; then
        7z x -y "$FILE_PATH" -o"$TEMP_PATH" > /dev/null
        FOUND=$(find "$TEMP_PATH" -type f \( -iname "*.qcow2" -o -iname "*.img" \) | head -n1)
        [ -n "$FOUND" ] && sudo mv "$FOUND" "$DISK_PATH"
    else
        sudo mv "$FILE_PATH" "$DISK_PATH"
    fi
    BOOT_OPTS="-boot c"
fi

# 4. بناء أمر QEMU (Legacy BIOS Mode)
# تم إزالة إعدادات pflash تماماً لضمان وضع الـ BIOS التقليدي
QEMU_BASE="sudo qemu-system-x86_64 -enable-kvm -cpu host -smp $VCPUS -m ${RAM}G"
QEMU_DRIVE="-hda $DISK_PATH"
QEMU_NET="-netdev user,id=net0 -device e1000,netdev=net0"
QEMU_DISPLAY="-vnc :0,password=on -monitor tcp:localhost:4444,server,nowait -display none"
QEMU_INPUT="-device usb-ehci,id=ehci -device usb-tablet,bus=ehci.0"
QEMU_MISC="-drive file=$VIRTIO_ISO,media=cdrom,if=none,id=cd1 -device ide-cd,bus=ide.1,drive=cd1"

FINAL_CMD="$QEMU_BASE $BOOT_OPTS $QEMU_DRIVE $QEMU_DISPLAY $QEMU_NET $QEMU_INPUT $QEMU_MISC -name $VM_NAME"

# 5. توليد ملف qemu_run.sh وتشغيله
echo "#!/bin/bash" | sudo tee "$RUN_SCRIPT" > /dev/null
echo "screen -dmS $VM_NAME $FINAL_CMD" | sudo tee -a "$RUN_SCRIPT" > /dev/null
sudo chmod +x "$RUN_SCRIPT"

echo "Rebuild finished. System is starting in BIOS mode..."
sudo bash "$RUN_SCRIPT"
sudo rm -rf "$TEMP_PATH"

# 6. تحديث الكاش
python3 -c "import json; d=json.load(open('$CACHE_FILE')); d['status']='completed'; json.dump(d, open('$CACHE_FILE','w'))"