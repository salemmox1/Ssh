from flask import Flask, render_template, jsonify, request
import psutil
import os
import subprocess
import json
from datetime import datetime

app = Flask(__name__)

# المسارات المحدثة بناءً على الهيكل الجديد
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DISK_PATH = os.path.join(BASE_DIR, "main_disk.qcow2")
SYSTEMS_JSON = os.path.join(BASE_DIR, "core/system/systems.json")
CACHE_FILE = os.path.join(BASE_DIR, "core/qemu/current_task.json")
EXECUTOR_SCRIPT = os.path.join(BASE_DIR, "core/qemu/executor.sh")
VM_NAME = "vortax_vm"

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get_modal/<type>")
def get_modal(type):
    try:
        return render_template(f"components/{type}.html")
    except:
        return "<p class='text-center text-red-400 font-mono'>[ERROR] COMPONENT_NOT_FOUND</p>", 404

@app.route("/api/systems_list")
def systems_list():
    if os.path.exists(SYSTEMS_JSON):
        with open(SYSTEMS_JSON, "r") as f:
            return jsonify(json.load(f))
    return jsonify({"self_install": {}, "preset": {}})

@app.route("/api/vm/action", methods=["POST"])
def vm_action():
    data = request.json
    action = data.get("action")
    
    if action == "start":
        subprocess.Popen(f"screen -dmS {VM_NAME} qemu-system-x86_64 -m 4G -hda {DISK_PATH} -net nic -net user", shell=True)
        return jsonify({"status": "success", "msg": "VM booting up..."})
    
    elif action == "stop":
        subprocess.run(f"screen -S {VM_NAME} -X quit", shell=True)
        return jsonify({"status": "info", "msg": "VM stopped safely"})
        
    elif action == "kill":
        subprocess.run("pkill -f qemu-system", shell=True)
        return jsonify({"status": "danger", "msg": "VM Terminated immediately"})

    elif action == "reboot":
        subprocess.run("pkill -f qemu-system", shell=True)
        subprocess.Popen(f"screen -dmS {VM_NAME} qemu-system-x86_64 -m 4G -hda {DISK_PATH}", shell=True)
        return jsonify({"status": "success", "msg": "System rebooting..."})
    
    return jsonify({"status": "error", "msg": "Unknown action"})

@app.route("/api/system/rebuild", methods=["POST"])
def rebuild_system():
    data = request.json
    sys_id = data.get("id")
    category = data.get("category")
    
    if not os.path.exists(SYSTEMS_JSON):
        return jsonify({"status": "error", "msg": "Configuration file missing"})

    with open(SYSTEMS_JSON, "r") as f:
        systems = json.load(f)
    
    target = None
    for sub_cat in systems.get(category, {}):
        for item in systems[category][sub_cat]:
            if item['id'] == sys_id:
                target = item
                break
        if target: break

    if not target:
        return jsonify({"status": "error", "msg": "Target system not found"})

    task_info = {
        "id": target['id'],
        "name": target['name'],
        "url": target['url'],
        "category": category,
        "disk_size": target.get('disk_size', 60),
        "status": "processing",
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    
    with open(CACHE_FILE, 'w') as f:
        json.dump(task_info, f)

    subprocess.Popen(["bash", EXECUTOR_SCRIPT, BASE_DIR])

    return jsonify({"status": "success", "msg": f"Task for {target['name']} started"})

@app.route("/stats")
def stats():
    cpu = psutil.cpu_percent()
    ram = psutil.virtual_memory()
    disk = psutil.disk_usage('/')
    
    actual_disk_size = 0
    if os.path.exists(DISK_PATH):
        actual_disk_size = round(os.path.getsize(DISK_PATH) / (1024**3), 2)
    
    return jsonify({
        "cpu": cpu,
        "ram_gb": round(ram.used / (1024**3), 1),
        "ram_pct": ram.percent,
        "disk_pct": round((actual_disk_size / 160) * 100, 1) if actual_disk_size > 0 else 0,
        "actual_disk": actual_disk_size,
        "free_disk": round(disk.free / (1024**3), 1),
        "time": datetime.now().strftime("%H:%M:%S")
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)